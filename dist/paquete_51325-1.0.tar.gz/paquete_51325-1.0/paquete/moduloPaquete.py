def funcion1():
    print("funcion 1 del modulo paquete")


def funcion2():
    print("funcion 2 del modulo paquete")
